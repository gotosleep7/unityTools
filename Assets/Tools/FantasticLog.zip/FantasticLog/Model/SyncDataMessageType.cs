public enum SyncDataMessageType
{
    MATERIAL = 1, RPC
}
